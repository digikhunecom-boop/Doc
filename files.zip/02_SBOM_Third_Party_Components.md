# SBOM و فهرست کتابخانه‌ها، SDK ها و مؤلفه‌های ثالث

**نام اپلیکیشن:** androidpospayment
**Application ID:** `ir.sadadpsp.apos`
**Version:** 02.02.01 (build 20201)
**تاریخ تهیه:** _____________
**مرجع استخراج:** `config/config.gradle`, `presentation/build.gradle`, `data/build.gradle`, `security/build.gradle`, `saferoom/build.gradle`

---

## ۱. ساختار ماژول‌های داخلی

| ماژول | نوع | مسئولیت |
|---|---|---|
| `presentation` | Android Application | UI، ViewModel، Service، DI |
| `data` | Android Library | Repository، ISO 8583، SDK دستگاه‌ها، دیتابیس |
| `domain` | Java Library (خالص) | Entity، UseCase، Interface |
| `security` | Android Library | تشخیص Root/Emulator/Debugger |
| `saferoom` | Android Library | لایه رمزنگاری Room (fork از CWAC-SafeRoom) |

معماری: Clean Architecture سه‌لایه با وابستگی یک‌طرفه `presentation → data → domain`.

---

## ۲. کتابخانه‌های Maven (مؤلفه‌های ثالث با منبع عمومی)

### ۲.۱ چارچوب و AndroidX

| # | Group : Artifact | Version | مجوز | کاربرد |
|---|---|---|---|---|
| ۱ | `androidx.appcompat:appcompat` | 1.0.2 | Apache-2.0 | سازگاری UI |
| ۲ | `androidx.constraintlayout:constraintlayout` | 1.1.3 | Apache-2.0 | چیدمان |
| ۳ | `androidx.lifecycle:lifecycle-extensions` | 2.0.0 | Apache-2.0 | ViewModel، LiveData |
| ۴ | `androidx.lifecycle:lifecycle-compiler` | 2.0.0 | Apache-2.0 | annotation processor |
| ۵ | `androidx.legacy:legacy-support-v4` | 1.0.2 | Apache-2.0 | سازگاری قدیمی |
| ۶ | `androidx.multidex:multidex` | 2.0.0 | Apache-2.0 | عبور از محدودیت 64K method |
| ۷ | `androidx.recyclerview:recyclerview` | 1.0.0 | Apache-2.0 | لیست تراکنش‌ها |
| ۸ | `androidx.localbroadcastmanager` | 1.1.0 | Apache-2.0 | ارتباط درون‌فرآیندی |
| ۹ | `androidx.work:work-runtime` | (متغیر `$work_version`) | Apache-2.0 | Advice/Reverse خودکار |
| ۱۰ | `androidx.startup:startup-runtime` | 1.1.1 | Apache-2.0 | راه‌اندازی مؤلفه‌ها |
| ۱۱ | `com.google.android.material:material` | 1.0.0 | Apache-2.0 | مؤلفه‌های UI |
| ۱۲ | `com.google.android.datatransport:transport-runtime` | 3.1.8 | Apache-2.0 | انتقال داده |

### ۲.۲ تزریق وابستگی

| # | Group : Artifact | Version | مجوز |
|---|---|---|---|
| ۱۳ | `com.google.dagger:dagger` | 2.31.2 | Apache-2.0 |
| ۱۴ | `com.google.dagger:dagger-android` | 2.31.2 | Apache-2.0 |
| ۱۵ | `com.google.dagger:dagger-android-support` | 2.31.2 | Apache-2.0 |
| ۱۶ | `com.google.dagger:dagger-compiler` | 2.31.2 | Apache-2.0 |
| ۱۷ | `com.google.dagger:dagger-android-processor` | 2.31.2 | Apache-2.0 |
| ۱۸ | `javax.inject:javax.inject` | 1 | Apache-2.0 |
| ۱۹ | `javax.annotation:jsr250-api` | 1.0 | CDDL-1.0 |

### ۲.۳ برنامه‌نویسی واکنشی

| # | Group : Artifact | Version | مجوز | کاربرد |
|---|---|---|---|---|
| ۲۰ | `io.reactivex.rxjava2:rxjava` | 2.2.5 | Apache-2.0 | خط لوله تراکنش |
| ۲۱ | `io.reactivex.rxjava2:rxandroid` | 2.1.0 | Apache-2.0 | Scheduler اندروید |
| ۲۲ | `com.github.pwittchen:reactivenetwork-rx2` | 3.0.8 | Apache-2.0 | پایش وضعیت شبکه |
| ۲۳ | `org.greenrobot:eventbus` | 3.2.0 | Apache-2.0 | رویداد درون‌اپلیکیشنی |

### ۲.۴ پایگاه داده و رمزنگاری ذخیره‌سازی

| # | Group : Artifact | Version | مجوز | کاربرد |
|---|---|---|---|---|
| ۲۴ | `androidx.room:room-runtime` | 2.2.0-rc01 | Apache-2.0 | ORM |
| ۲۵ | `androidx.room:room-compiler` | 2.2.0-rc01 | Apache-2.0 | annotation processor |
| ۲۶ | `net.zetetic:android-database-sqlcipher` | 3.5.9 | BSD-style | **رمزنگاری AES-256 دیتابیس** |
| ۲۷ | `com.commonsware.cwac:saferoom` | 0.4.2 | Apache-2.0 | پیوند Room ↔ SQLCipher |
| ۲۸ | `com.orhanobut:hawk` | 2.0.1 | Apache-2.0 | ذخیره‌سازی key-value رمزشده |

⚠️ `room-runtime 2.2.0-rc01` نسخه **release candidate** است. جزئیات در بخش ۷.

### ۲.۵ رمزنگاری

| # | Group : Artifact | Version | مجوز | کاربرد |
|---|---|---|---|---|
| ۲۹ | `org.bouncycastle:bcprov-jdk15on` | 1.65 | MIT-style | provider رمزنگاری |
| ۳۰ | `org.bouncycastle:bcpkix-jdk15on` | 1.65 | MIT-style | تولید گواهی X.509 برای سرور محلی |

### ۲.۶ شبکه و پروتکل

| # | Group : Artifact | Version | مجوز | کاربرد |
|---|---|---|---|---|
| ۳۱ | `com.squareup.okhttp3:okhttp` | 4.10.0 | Apache-2.0 | HTTP client |
| ۳۲ | `com.github.Miaadrajabi:iso8583TCPSocketClient` | 1.3.2 | (نیازمند بررسی) | **سوکت TCP ارتباط با سوییچ** |
| ۳۳ | `com.imohsenb:ISO8583` | 1.0.2 | (نیازمند بررسی) | **کدگذاری/کدگشایی ISO 8583** |
| ۳۴ | `org.nanohttpd:nanohttpd` | 2.3.1 | BSD-3 | سرور HTTP محلی (PC-POS) |
| ۳۵ | `org.java-websocket:Java-WebSocket` | 1.5.3 | MIT | ارتباط WebSocket |
| ۳۶ | `com.koushikdutta.async:androidasync` | 3.0.9 | Apache-2.0 | I/O غیرهم‌زمان |

⚠️ موارد ۳۲ و ۳۳ مؤلفه‌های حساس در مسیر داده پرداخت هستند و از مخازن شخصی (GitHub/JitPack)
تأمین می‌شوند. بخش ۷.

### ۲.۷ سریال‌سازی

| # | Group : Artifact | Version | مجوز |
|---|---|---|---|
| ۳۷ | `com.google.code.gson:gson` | 2.8.4 | Apache-2.0 |
| ۳۸ | `com.fasterxml.jackson:jackson-bom` | 2.12.5 | Apache-2.0 |
| ۳۹ | `com.fasterxml.jackson.core:jackson-core` | 2.12.5 | Apache-2.0 |
| ۴۰ | `com.fasterxml.jackson.core:jackson-databind` | 2.12.5 | Apache-2.0 |
| ۴۱ | `com.fasterxml.jackson.core:jackson-annotations` | 2.12.5 | Apache-2.0 |
| ۴۲ | `com.fasterxml.jackson.dataformat:jackson-dataformat-xml` | 2.12.5 | Apache-2.0 |
| ۴۳ | `com.fasterxml.jackson.module:jackson-module-kotlin` | 2.12.5 | Apache-2.0 |
| ۴۴ | `com.fasterxml.woodstox:woodstox-core` | 6.2.6 | Apache-2.0 |
| ۴۵ | `org.codehaus.woodstox:stax2-api` | 4.2.1 | BSD-2 |
| ۴۶ | `javax.xml.stream:stax-api` | 1.0-2 | CDDL |

### ۲.۸ رابط کاربری و ابزار

| # | Group : Artifact | Version | مجوز | کاربرد |
|---|---|---|---|---|
| ۴۷ | `io.github.inflationx:calligraphy3` | 2.3.0 | Apache-2.0 | فونت فارسی |
| ۴۸ | `io.github.inflationx:viewpump` | (متغیر) | Apache-2.0 | تزریق View |
| ۴۹ | `uk.co.chrisjenx:calligraphy` | 2.3.0 | Apache-2.0 | فونت (نسخه قدیمی) |
| ۵۰ | `pl.droidsonroids.gif:android-gif-drawable` | 1.2.12 | MIT | انیمیشن GIF |
| ۵۱ | `com.github.samanzamani:PersianDate` | 1.7.1 | Apache-2.0 | تاریخ شمسی |
| ۵۲ | `com.aminography:primedatepicker` | 3.6.1 | Apache-2.0 | انتخاب تاریخ |
| ۵۳ | `me.dm7.barcodescanner:zbar` | 1.9.8 | Apache-2.0 | **اسکن بارکد/QR** |
| ۵۴ | `com.github.aabhasr1:OtpView` | v1.1.2-ktx | Apache-2.0 | ورود OTP |
| ۵۵ | `org.jetbrains:annotations` | 15.0 | Apache-2.0 | annotation |
| ۵۶ | `org.projectlombok:lombok` | 1.18.10 | MIT | کاهش boilerplate (compile-time) |
| ۵۷ | `com.jakewharton.timber:timber` | 4.7.1 | Apache-2.0 | لاگ‌گیری |

### ۲.۹ کتابخانه‌های تست (در APK نهایی حاضر نیستند)

| # | Group : Artifact | Version |
|---|---|---|
| ۵۸ | `junit:junit` | 4.12 |
| ۵۹ | `org.mockito:mockito-core` | 2.6.3 |
| ۶۰ | `org.assertj:assertj-core` | 1.7.1 |
| ۶۱ | `androidx.room:room-testing` | 2.0.0-alpha1 |
| ۶۲ | `androidx.arch.core:core-testing` | 2.0.0 |
| ۶۳ | `androidx.multidex:multidex-instrumentation` | 2.0.0 |

---

## ۳. SDK های سازندگان ترمینال (JAR محلی)

این‌ها فایل‌های JAR بومی هستند که مستقیماً از سازنده دریافت شده و در مخزن پروژه نگهداری می‌شوند.
هیچ‌کدام از مخزن عمومی تأمین نمی‌شوند.

### ۳.۱ Kozen (دستگاه‌های اصلی — D300, P10)

| # | فایل | مسیر | کاربرد |
|---|---|---|---|
| ۱ | `com.pos.sdk_release.jar` | `data/libs/kozen/` | **PED، EMV، چاپگر، کارت‌خوان** |
| ۲ | `libCustomAPI-1.5.5.jar` | `data/libs/kozen/` | API اختصاصی سازنده |
| ۳ | `SDK8Series.jar` | `data/external-libs/` | سری ۸ Kozen |

### ۳.۲ PAX

| # | فایل | کاربرد |
|---|---|---|
| ۴ | `NeptuneLiteApi_V3.31.00_20220909.jar` | SDK کامل PAX |

### ۳.۳ Castles Technology

| # | فایل | کاربرد |
|---|---|---|
| ۵ | `CTOS.CtCrypto_0.0.2.jar` | **عملیات رمزنگاری** |
| ۶ | `CTOS.CtKMS2_0.2.6.jar` | **مدیریت کلید** |
| ۷ | `CTOS.CtEMV_0.0.9.jar` | کرنل EMV تماسی |
| ۸ | `CTOS.CtEMVCL_0.0.5.jar` | کرنل EMV بی‌تماس |
| ۹ | `CTOS.CtSC_0.0.1.jar` | کارت هوشمند |
| ۱۰ | `CTOS.CtPrint_0.0.5.jar` | چاپگر |
| ۱۱ | `CTOS.CtBarcodeReader_0.0.1.jar` | بارکدخوان |
| ۱۲ | `CTOS.CtFP_0.0.3.jar` | اثر انگشت |
| ۱۳ | `CTOS.CtSystem_0.0.7.jar` | سیستم |
| ۱۴ | `CTOS.CtLoader_0.0.7.jar` | بارگذار |
| ۱۵ | `CTOS.CtExtraApp_0.0.1.jar` | اپلیکیشن جانبی |
| ۱۶ | `CTOS.CtExtraStorage_0.0.1.jar` | ذخیره‌سازی |

### ۳.۴ Vanstone

| # | فایل | کاربرد |
|---|---|---|
| ۱۷ | `vanstoneSdkClient-noemv_20240724.jar` | SDK اصلی |
| ۱۸ | `AppSdkAidl_buildBy_20240723.jar` | AIDL |
| ۱۹ | `Common.jar` | مشترک |
| ۲۰ | `PayPass.jar` | Mastercard PayPass |
| ۲۱ | `PayPassGenAAC.jar` | تولید AAC |

### ۳.۵ سایر سازندگان

| # | فایل | سازنده |
|---|---|---|
| ۲۲ | `bluebird-payment-sdk-sp500.jar` | BlueBird SP500 |
| ۲۳ | `platform_sdk_v4.0.0115.jar` | Urovo |

### ۳.۶ کتابخانه‌های محلی متفرقه

| # | فایل | کاربرد | ملاحظه |
|---|---|---|---|
| ۲۴ | `ManamPersianDate.jar` | تاریخ شمسی | تأمین‌کننده داخلی |
| ۲۵ | `http-20070405.jar` | Apache HttpClient قدیمی | ⚠️ بخش ۷ |
| ۲۶ | `ISO8583-1.0.2.jar` | ISO 8583 (نسخه JAR) | ⚠️ تکراری با Maven |
| ۲۷ | `libs/artifactId:1.0.0` | ⚠️ نام نامشخص | بخش ۷ |

---

## ۴. جمع‌بندی عددی SBOM

| دسته | تعداد |
|---|---|
| کتابخانه Maven (production) | ۵۷ |
| کتابخانه Maven (test-only) | ۶ |
| SDK سازنده ترمینال (JAR محلی) | ۲۳ |
| کتابخانه محلی متفرقه | ۴ |
| ماژول داخلی | ۵ |
| **مجموع مؤلفه‌های ثالث** | **۸۴** |

---

## ۵. مؤلفه‌های واقع در مسیر داده حساس

مؤلفه‌هایی که به PAN، PIN Block، Track2 یا کلید رمزنگاری دسترسی دارند و باید در ارزیابی
امنیتی اولویت داشته باشند:

| مؤلفه | نوع دسترسی |
|---|---|
| `com.pos.sdk_release.jar` (Kozen) | PED، PIN Block، کلید، Track2 |
| `CTOS.CtCrypto`, `CTOS.CtKMS2` (Castles) | رمزنگاری، مدیریت کلید |
| `NeptuneLiteApi` (PAX) | PED، کلید |
| `vanstoneSdkClient`, `PayPass*` | EMV، کلید |
| `iso8583TCPSocketClient` 1.3.2 | انتقال پیام حاوی F35/F52 |
| `com.imohsenb:ISO8583` 1.0.2 | کدگذاری F35/F52 |
| `android-database-sqlcipher` 3.5.9 | رمزنگاری `encPan` در دیتابیس |
| `saferoom` 0.4.2 | پیوند رمزنگاری دیتابیس |
| `bouncycastle` 1.65 | provider رمزنگاری |
| `hawk` 2.0.1 | ذخیره پیکربندی |

---

## ۶. تولید SBOM ماشین‌خوان

شاپرک احتمالاً فرمت استاندارد (CycloneDX یا SPDX) می‌خواهد. برای تولید:

```gradle
// در build.gradle سطح root
plugins {
    id 'org.cyclonedx.bom' version '1.8.2'
}

cyclonedxBom {
    includeConfigs = ["releaseRuntimeClasspath"]
    outputFormat = "json"
    outputName = "sbom-androidpospayment-02.02.01"
}
```

```bash
./gradlew cyclonedxBom
```

خروجی در `build/reports/` تولید می‌شود.

⚠️ **محدودیت مهم:** ابزارهای خودکار SBOM فقط وابستگی‌های **Maven** را پیدا می‌کنند.
۲۳ فایل JAR سازندگان و ۴ JAR محلی (بخش‌های ۳ و ۳.۶) در خروجی نخواهند بود و باید
**دستی** به SBOM اضافه شوند. برای هر JAR محلی این اقلام لازم است:

- نام و نسخه دقیق
- تأمین‌کننده (سازنده)
- SHA-256 فایل
- تاریخ دریافت و کانال دریافت
- مجوز یا قرارداد

```bash
# تولید hash برای JAR های محلی
find . -name "*.jar" -path "*libs*" -not -path "*/build/*" \
  -exec sh -c 'echo "$(sha256sum "$1")"' _ {} \;
```

---

## ۷. یافته‌های نیازمند اقدام پیش از ارسال

این بخش برای مصرف داخلی است. ارزیاب شاپرک به احتمال زیاد همین موارد را خواهد پرسید.

### ۷.۱ اولویت بالا

| # | یافته | ریسک | اقدام |
|---|---|---|---|
| ۱ | `iso8583TCPSocketClient:1.3.2` از JitPack / مخزن شخصی | مؤلفه‌ای در مسیر داده کارت با نگهداری فردی و بدون SLA | بررسی امکان fork داخلی + audit کد + تثبیت نسخه با hash |
| ۲ | `com.imohsenb:ISO8583:1.0.2` — مخزن شخصی | همان | همان |
| ۳ | `http-20070405.jar` — Apache HttpClient نسخه ۲۰۰۷ | کتابخانه ۱۸ ساله بدون وصله امنیتی | حذف و مهاجرت به OkHttp (که از قبل موجود است) |
| ۴ | `libs/artifactId:1.0.0` — نام نامشخص | مؤلفه ناشناس در APK؛ ارزیاب قطعاً سؤال می‌کند | شناسایی، مستندسازی یا حذف |
| ۵ | `android-database-sqlcipher:3.5.9` | نسخه قدیمی؛ شاخه ۴.x موجود است | ارتقا (نیازمند تست migration) |

### ۷.۲ اولویت متوسط

| # | یافته | اقدام |
|---|---|---|
| ۶ | `room-runtime:2.2.0-rc01` — نسخه RC در محیط production | ارتقا به آخرین نسخه stable شاخه 2.2.x |
| ۷ | `ISO8583` هم به‌صورت Maven و هم JAR محلی | یکی حذف شود؛ خطر تعارض کلاس |
| ۸ | `calligraphy` و `calligraphy3` هر دو حاضر | نسخه قدیمی حذف شود |
| ۹ | `bouncycastle:1.65` (منتشرشده ۲۰۲۰) | بررسی CVE و ارتقا |
| ۱۰ | `okhttp:4.10.0` | ارتقا به آخرین 4.x |
| ۱۱ | `fileTree(dir: 'libs', include: ['*.jar', '*.aar'])` | این الگو هر فایل موجود در `libs` را بی‌صدا وارد build می‌کند. برای SBOM قابل اتکا، وابستگی‌ها باید صریح فهرست شوند |

### ۷.۳ اقدامات پیش‌نیاز مستندسازی

- [ ] اسکن CVE با `dependency-check` یا `OSV-Scanner` و ضمیمه کردن گزارش
- [ ] استخراج SHA-256 همه JAR های محلی
- [ ] تعیین وضعیت مجوز `iso8583TCPSocketClient` و `com.imohsenb:ISO8583`
- [ ] دریافت تأییدیه/قرارداد مجوز از سازندگان ترمینال برای SDK ها
- [ ] تعیین اینکه SDK کدام سازندگان در نسخه ارسالی **واقعاً فعال** است — اگر فقط Kozen
      روی ترمینال هدف اجرا می‌شود، حضور SDK پنج سازنده دیگر در APK باید توجیه شود
      (افزایش سطح حمله بدون کاربرد عملیاتی)

### ۷.۴ نکته درباره حجم APK و سطح حمله

اپلیکیشن SDK **شش سازنده** ترمینال را همزمان حمل می‌کند (Kozen، PAX، Castles، Vanstone،
BlueBird، Urovo). این معماری از نظر انعطاف مطلوب است ولی:

- سطح حمله را چند برابر می‌کند
- کد بومی (`.so`) سازندگان غیرفعال هم در APK حاضر است
- ارزیاب امنیتی احتمالاً می‌پرسد چرا SDK ای که روی این ترمینال اجرا نمی‌شود در بسته حضور دارد

**پیشنهاد:** استفاده از Gradle product flavor به‌ازای هر سازنده، تا نسخه ارسالی برای
ارزیابی فقط SDK همان دستگاه هدف را داشته باشد.

---

## ۸. تنظیمات Build مرتبط با امنیت

| مورد | مقدار فعلی | ارزیابی |
|---|---|---|
| `minifyEnabled` (release) | `true` | ✅ |
| `proguardFiles` | `proguard-android.txt` + `proguard-rules.pro` | ✅ |
| `shrinkResources` | `false` | قابل بهبود |
| `minifyEnabled` (debug) | `false` | ✅ طبیعی |
| `allowBackup` | `false` | ✅ |
| `targetSdkVersion` | 28 | ⚠️ سند ۰۱ بخش ۶.۲ |
| `buildToolsVersion` | 30.0.2 | قابل ارتقا |

---

**تنظیم‌کننده:** _____________  **سمت:** _____________
**تأیید مسئول امنیت:** _____________
**تأیید مدیر فنی:** _____________
