# فهرست Permission ها، Privilege ها و Capability ها

**نام اپلیکیشن:** androidpospayment
**Application ID:** `ir.sadadpsp.apos`
**Version Name / Code:** 02.02.01 / 20201
**minSdk / targetSdk / compileSdk:** 23 / 28 / 31
**تهیه‌کننده:** شرکت پرداخت الکترونیک سداد
**تاریخ تهیه:** ‌‌_____________
**مرجع استخراج:** `presentation/src/main/AndroidManifest.xml`

---

> **توجه پیش از ارسال:** موارد مشخص‌شده با علامت ⚠️ نیازمند تصمیم فنی/مدیریتی هستند و
> **قبل از ارسال به شاپرک** باید یا حذف شوند یا توجیه مکتوب برایشان تهیه شود.
> بخش ۶ این سند فهرست اقدامات لازم را دارد.

---

## ۱. Permission های سیستمی درخواست‌شده

### ۱.۱ گروه شبکه و ارتباطات

| # | Permission | Protection Level | ضرورت عملیاتی | محل استفاده |
|---|---|---|---|---|
| ۱ | `android.permission.INTERNET` | normal | ارتباط ISO 8583 با سوییچ سداد | `SwitchClient`, `IsoClient` |
| ۲ | `android.permission.ACCESS_NETWORK_STATE` | normal | تشخیص قطعی شبکه پیش از ارسال تراکنش | `ReactiveNetwork`, `PosApplication` |
| ۳ | `android.permission.ACCESS_WIFI_STATE` | normal | نمایش وضعیت اتصال در StatusBar و تشخیص نوع بستر | لایه Presentation |

### ۱.۲ گروه ذخیره‌سازی

| # | Permission | Protection Level | ضرورت عملیاتی | ملاحظه |
|---|---|---|---|---|
| ۴ | `android.permission.WRITE_EXTERNAL_STORAGE` | dangerous | نوشتن فایل لاگ و به‌روزرسانی | `maxSdkVersion="32"` — محدودشده |
| ۵ | `android.permission.READ_EXTERNAL_STORAGE` | dangerous | خواندن فایل به‌روزرسانی TMS | `maxSdkVersion="32"` — محدودشده |
| ۶ | `android.permission.MANAGE_EXTERNAL_STORAGE` | **special (All files access)** | ⚠️ نیازمند توجیه | بخش ۶ |

### ۱.۳ گروه سخت‌افزار و دستگاه

| # | Permission | Protection Level | ضرورت عملیاتی |
|---|---|---|---|
| ۷ | `android.permission.CAMERA` | dangerous | اسکن بارکد/QR قبض و شناسه پرداخت (`zbar`) |
| ۸ | `android.permission.VIBRATE` | normal | بازخورد لمسی هنگام کشیدن/قرار دادن کارت |
| ۹ | `android.permission.READ_PHONE_STATE` | dangerous | خواندن IMEI برای شناسه یکتای ترمینال (FC 041 در Logon) |
| ۱۰ | `android.permission.READ_SMS` | dangerous | ⚠️ نیازمند توجیه — بخش ۶ |

### ۱.۴ گروه چرخه حیات و سرویس

| # | Permission | Protection Level | ضرورت عملیاتی |
|---|---|---|---|
| ۱۱ | `android.permission.RECEIVE_BOOT_COMPLETED` | normal | راه‌اندازی خودکار ترمینال پس از قطع برق |
| ۱۲ | `android.permission.FOREGROUND_SERVICE` | normal | سرویس Logon و TMS در پیش‌زمینه |
| ۱۳ | `android.permission.FOREGROUND_SERVICE_DATA_SYNC` | normal | نوع سرویس پیش‌زمینه (الزام Android 14+) |
| ۱۴ | `android.permission.WAKE_LOCK` | normal | جلوگیری از خواب دستگاه در میانه تراکنش |
| ۱۵ | `android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | normal | تضمین اجرای Logon زمان‌بندی‌شده |
| ۱۶ | `android.permission.SCHEDULE_EXACT_ALARM` | normal | زمان‌بندی دقیق Logon و تسویه |
| ۱۷ | `android.permission.POST_NOTIFICATIONS` | dangerous | اعلان وضعیت سرویس (الزام Android 13+) |

### ۱.۵ گروه رابط کاربری و kiosk mode

| # | Permission | Protection Level | ضرورت عملیاتی |
|---|---|---|---|
| ۱۸ | `android.permission.SYSTEM_ALERT_WINDOW` | **special** | نمایش لایه امن ورود PIN روی سایر اپلیکیشن‌ها |
| ۱۹ | `android.permission.SYSTEM_OVERLAY_WINDOW` | signature | ⚠️ بلااستفاده — بخش ۶ |
| ۲۰ | `android.permission.USE_FULL_SCREEN_INTENT` | normal | نمایش تمام‌صفحه تراکنش ورودی |
| ۲۱ | `android.permission.DISABLE_KEYGUARD` | dangerous | حذف قفل صفحه در حالت ترمینال اختصاصی |
| ۲۲ | `android.permission.REORDER_TASKS` | normal | بازگرداندن اپلیکیشن به پیش‌زمینه پس از تراکنش |

### ۱.۶ Permission های محافظت‌شده (Protected / signatureOrSystem)

| # | Permission | Protection Level | وضعیت |
|---|---|---|---|
| ۲۳ | `android.permission.READ_LOGS` | **signature\|privileged** | ⚠️ با `tools:ignore="ProtectedPermissions"` — بخش ۶ |
| ۲۴ | `android.permission.WRITE_SETTINGS` | **signature\|appop** | ⚠️ با `tools:ignore="ProtectedPermissions"` — بخش ۶ |

> این دو مورد فقط در صورتی اعطا می‌شوند که اپلیکیشن با کلید سیستم امضا شده یا در
> `/system/priv-app` نصب شده باشد. روی ترمینال‌های Kozen D300/P10 اپلیکیشن به‌عنوان
> **system app** توسط سازنده pre-install می‌شود.
>
> **نکته:** استفاده از `tools:ignore` فقط هشدار Lint را خاموش می‌کند و مجوزی اعطا نمی‌کند.
> در دستگاه‌های غیر pre-install این Permission ها اعطا نمی‌شوند و کد باید graceful degradation
> داشته باشد.

---

## ۲. Permission های اختصاصی تعریف‌شده توسط اپلیکیشن

اپلیکیشن پنج Permission سطح اپلیکیشن تعریف می‌کند تا سایر اپلیکیشن‌های اکوسیستم سداد
(مانند اپلیکیشن پذیرنده) بتوانند از سرویس‌های آن استفاده کنند:

| # | Permission | Protection Level | Flags | کاربرد |
|---|---|---|---|---|
| ۱ | `ir.sadadpsp.apos.permission.PAYMENT_SERVICE` | normal | `costsMoney` | فراخوانی سرویس پرداخت از اپلیکیشن ثالث |
| ۲ | `ir.sadadpsp.apos.permission.PRINT_SERVICE` | normal | — | فراخوانی سرویس چاپ رسید |
| ۳ | `ir.sadadpsp.apos.permission.ACCOUNT_CONTENT` | normal | — | دسترسی به ContentProvider اطلاعات حساب |
| ۴ | `ir.sadadpsp.apos.permission.APP_CONTENT` | normal | — | دسترسی به ContentProvider اطلاعات اپلیکیشن |
| ۵ | `ir.sadadpsp.apos.permission.CARD_SWIPE_SERVICE` | normal | — | فراخوانی سرویس خواندن کارت |
| ۶ | `ir.sadadpsp.apos.presentation.permission.C2D_MESSAGE` | **signature** | — | دریافت پیام push |

⚠️ **یافته مهم:** پنج Permission اول `protectionLevel="normal"` هستند. یعنی **هر اپلیکیشنی**
که روی دستگاه نصب شود می‌تواند آن‌ها را در manifest خود اعلام کند و بدون تأیید کاربر یا
بررسی امضا به سرویس پرداخت دسترسی بگیرد. جزئیات و اقدام اصلاحی در بخش ۶.

---

## ۳. Permission های درخواست‌شده از اپلیکیشن‌های دیگر اکوسیستم

| # | Permission | صاحب | کاربرد |
|---|---|---|---|
| ۱ | `ir.sadadpsp.merchant.permission.RESULT_PRINT_SERVICE` | اپلیکیشن پذیرنده | دریافت نتیجه چاپ |
| ۲ | `ir.sadadpsp.merchant.permission.ACCOUNT_CONTENT` | اپلیکیشن پذیرنده | خواندن اطلاعات حساب پذیرنده |
| ۳ | `ir.service.sadadtms.permission.BIND_UPDATE_SERVICE` | SadadTMS | اتصال AIDL به سرویس به‌روزرسانی |
| ۴ | `com.google.android.c2dm.permission.RECEIVE` | Google Play Services | دریافت پیام push |
| ۵ | `ir.sadadpsp.apos.presentation.c2dm.permission.RECEIVE` | خود اپلیکیشن | دریافت پیام push |

---

## ۴. Privilege های سطح دستگاه (Device / PED Privileges)

این‌ها Permission اندرویدی نیستند بلکه دسترسی‌هایی هستند که از طریق SDK اختصاصی سازنده
ترمینال و پس از امضا/تأیید سازنده در اختیار اپلیکیشن قرار می‌گیرند.

| # | Privilege | مسیر دسترسی | عملیات |
|---|---|---|---|
| ۱ | دسترسی به PED (PIN Entry Device) | `POIHsmManage`, `PedWriteKey` | تزریق و مدیریت کلید TMK/TPK/TAK/TDK |
| ۲ | تولید PIN Block | `CustomPasswordDialog`, `GeneratePinParam` | تولید PIN Block در SE، خارج از حافظه اپلیکیشن |
| ۳ | تولید MAC | `PedCalcMAC` (شاخص TAK) | امضای پیام ISO 8583 |
| ۴ | خواندن Track2 مغناطیسی | `POIMagCardManager` | خواندن کارت مغناطیسی |
| ۵ | کرنل EMV تماسی | `POIEmvCoreManager` | پردازش کارت تماسی |
| ۶ | کرنل EMV بی‌تماس | `POIEmvCoreManager` + NFC | پردازش کارت بی‌تماس |
| ۷ | کنترل چاپگر حرارتی | `POIPrinterManager` | چاپ رسید |
| ۸ | خواندن شماره سریال دستگاه | `PosUtils.getSN()` | شناسه یکتای ترمینال |
| ۹ | کنترل صفحه‌کلید امن | SDK Kozen | ورود PIN |
| ۱۰ | نصب/به‌روزرسانی silent | AIDL به `SadadTMS` | به‌روزرسانی نسخه از راه دور |

> **نکته امنیتی:** کلیدهای رمزنگاری هرگز در حافظه اپلیکیشن یا دیتابیس ذخیره نمی‌شوند.
> عملیات با ارجاع به **شاخص کلید** در Secure Element انجام می‌شود:
>
> | شاخص | نوع کلید | ثابت در کد |
> |---|---|---|
> | 1 | TMK | `TMK_INDX` |
> | 2 | TPK (PIN) | `TPK_INDX` |
> | 3 | TAK (MAC) | `TAK_INDX` |
> | 8 | TMK as TDK | `TMK_AS_TDK_INDX` |
> | 9 | TMK as TAK | `TMK_AS_TAK_INDX` |

---

## ۵. Capability ها

### ۵.۱ اجزای Export شده

مجموعاً **۱۴ جزء** با `android:exported="true"` اعلام شده‌اند. جدول کامل با وضعیت محافظت:

| جزء | نوع | Permission محافظ | ارزیابی |
|---|---|---|---|
| `PaymentService` | Service | `ir.sadadpsp.apos.permission.PAYMENT_SERVICE` | ⚠️ normal |
| `PrintIntentService` | Service | — | ⚠️ بدون محافظت |
| `LogonIntentService` | Service | `android.permission.BIND_JOB_SERVICE` | ✅ سیستمی |
| `CardSwipeService` | Service | `ir.sadadpsp.apos.permission.CARD_SWIPE_SERVICE` | ⚠️ normal |
| `AccountContentProvider` | Provider | `ir.sadadpsp.apos.permission.ACCOUNT_CONTENT` | ⚠️ normal |
| `AppContentProvider` | Provider | `ir.sadadpsp.apos.permission.APP_CONTENT` | ⚠️ normal |
| سایر (۸ مورد) | Activity / Receiver | متغیر | نیازمند بازبینی موردی |

> **اقدام لازم:** فهرست دقیق ۱۴ جزء با `grep -n 'android:exported="true"' AndroidManifest.xml -B 5`
> استخراج و در نسخه نهایی این سند به‌صورت کامل درج شود.

### ۵.۲ Capability های فنی اپلیکیشن

| # | Capability | پیاده‌سازی |
|---|---|---|
| ۱ | تراکنش خرید / بازگشت / تسویه / موجودی | `SadadSwitchRepo` |
| ۲ | پرداخت قبض، شارژ، شبا | `SadadSwitchRepo` |
| ۳ | Logon و مدیریت کلید | FC 010, 041, 044, 059 |
| ۴ | Reverse و Advice خودکار | `AutoAdviceWorker` |
| ۵ | چاپ رسید (سه‌بخشی + لوگو شاپرک) | `KozenDeviceRepo.print()` |
| ۶ | گزارش مصرف رول کاغذ | FC 059 |
| ۷ | به‌روزرسانی از راه دور | AIDL ↔ SadadTMS |
| ۸ | سرور محلی HTTPS (PC-POS) | `LocalHttpServer`, `nanohttpd` |
| ۹ | تشخیص Root / Emulator / Debugger | ماژول `security` |
| ۱۰ | دیتابیس رمزشده | Room + SQLCipher (SafeRoom) |

### ۵.۳ حالت اجرا

اپلیکیشن در حالت **ترمینال اختصاصی (Dedicated / Kiosk)** اجرا می‌شود:

- `android:allowBackup="false"` — ✅ backup غیرفعال
- `DISABLE_KEYGUARD` — حذف قفل صفحه
- `REORDER_TASKS` — بازگشت اجباری به پیش‌زمینه
- `SYSTEM_ALERT_WINDOW` — لایه امن روی سایر اپلیکیشن‌ها

---

## ۶. یافته‌های نیازمند اقدام پیش از ارسال

این بخش **برای مصرف داخلی** است و در نسخه ارسالی به شاپرک باید به «توجیه» یا «رفع» تبدیل شود.

### ۶.۱ اولویت بالا

| # | یافته | ریسک | اقدام پیشنهادی |
|---|---|---|---|
| ۱ | پنج Permission اختصاصی با `protectionLevel="normal"` | هر اپ نصب‌شده می‌تواند سرویس پرداخت را فراخوانی کند | تغییر به `signature` یا `signatureOrSystem`؛ اگر اپ پذیرنده با کلید دیگری امضا می‌شود، از `signature` با اشتراک کلید یا بررسی صریح `PackageManager.checkSignatures()` در بدنه سرویس استفاده شود |
| ۲ | `PrintIntentService` بدون Permission، `exported="true"` | هر اپ می‌تواند چاپ دلخواه انجام دهد؛ امکان چاپ رسید جعلی | افزودن `android:permission="ir.sadadpsp.apos.permission.PRINT_SERVICE"` |
| ۳ | `READ_SMS` | دسترسی به کل پیام‌های دستگاه؛ حساسیت بالا از دید ارزیاب | اگر برای OTP است، به `SMS Retriever API` مهاجرت شود که Permission نمی‌خواهد. اگر بلااستفاده است، حذف شود |
| ۴ | `MANAGE_EXTERNAL_STORAGE` | دسترسی به کل فایل‌سیستم | با `MediaStore` یا `getExternalFilesDir()` جایگزین شود؛ در غیر این صورت توجیه مکتوب لازم است |

### ۶.۲ اولویت متوسط

| # | یافته | اقدام |
|---|---|---|
| ۵ | `READ_LOGS` + `tools:ignore` | حذف شود مگر برای پشتیبانی میدانی ضروری باشد. اگر لازم است، به `debug` variant محدود شود |
| ۶ | `WRITE_SETTINGS` + `tools:ignore` | تعیین دقیق کدام setting نوشته می‌شود؛ اگر تنظیم `screen timeout` است، جایگزین‌های بدون Permission بررسی شود |
| ۷ | `SYSTEM_OVERLAY_WINDOW` | این Permission در اندروید مدرن وجود ندارد و بی‌اثر است — حذف شود |
| ۸ | ارتباط سوییچ با `ConnectionMode.BLOCKING` و بدون TLS | تأیید شود که رمزنگاری در لایه پیام (MAC + PIN Block) کافی است یا mTLS الزامی است — نامه شاپرک به mTLS اشاره دارد |
| ۹ | `targetSdkVersion = 28` در حالی که `compileSdk = 31` | بسیاری از سخت‌گیری‌های امنیتی اندروید مبتنی بر targetSdk اعمال می‌شوند؛ ارزیاب احتمالاً این را سؤال می‌کند |

### ۶.۳ نظافت manifest

Permission های زیر **تکراری** اعلام شده‌اند. بی‌اثر است ولی در بازبینی دستی به‌عنوان بی‌دقتی
تلقی می‌شود:

- `ACCESS_NETWORK_STATE` — ۲ بار
- `DISABLE_KEYGUARD` — ۲ بار
- `WAKE_LOCK` — ۲ بار
- `FOREGROUND_SERVICE` — ۳ بار

---

## ۷. جمع‌بندی عددی

| دسته | تعداد |
|---|---|
| Permission سیستمی | ۲۴ |
| — از این تعداد dangerous | ۷ |
| — از این تعداد special/protected | ۴ |
| Permission اختصاصی تعریف‌شده | ۶ |
| Permission درخواستی از سایر اپ‌ها | ۵ |
| Privilege سطح PED/دستگاه | ۱۰ |
| جزء Export شده | ۱۴ |

---

**تنظیم‌کننده:** _____________  **سمت:** _____________
**تأیید مسئول امنیت:** _____________
**تأیید مدیر فنی:** _____________
